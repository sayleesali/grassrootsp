<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <!-- tailwindcss cdn link -->
    <script src="https://cdn.tailwindcss.com"></script>

    <!-- CSS file -->
    <link rel="stylesheet" href="<?php echo e(asset('css/fstyle.css')); ?>">

</head>
<body class="flex justify-center mt-10">
<div class="w-[1300px] h-[480px] footerblock">


<div class="container mx-auto flex items-center justify-between">
            <!-- Logo -->
            <div class="text-white ml-20 mt-6">
                <img src="/img/logofc.png" alt="Logo" class="h-14">
                <p class="mt-2 text-gray-300">Grassroots Growth Initiative Inc. is a digital</p>
                 <p class="text-gray-300">marketing agency based on planet earth</p>
                  <p class="text-gray-300">established © 2024</p>
                </p>
            </div>
            <!-- Navigation Pages -->
            <nav class="text-white mt-14 fcnav">
                <ul class="flex space-x-4">
                    <li><a href="#" class="font-bold">Contact</a>
                    <ul class="mt-3">
                        <li class="mt-1"><a href="#" class="text-gray-300">Phone</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Email</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Location</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Social Media</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Message Form</li>
                    </ul>
                </li>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <li><a href="#" class="font-bold">About Us</a>
                    <ul class="mt-3">
                        <li class="mt-1"><a href="#" class="text-gray-300">Who We Are</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Our Program</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">What We Doing</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Testimonial</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Our Blogs</li>
                    </ul>
                </li>
                &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                    <li><a href="#" class="font-bold">Services</a>
                    <ul class="mt-3">
                        <li class="mt-1"><a href="#" class="text-gray-300">Courses</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Events & Fair</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Networking</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Contact us</li>
                        <li class="mt-1"><a href="#" class="text-gray-300">Why Become an Ambassador</li>
                    </ul>
                </li>
                </ul>
            </nav>
        </div>

        <p class="ml-20 mt-16 text-2xl text-white font-bold">Campus Ambassador Program</p>
        <p class="ml-20 mt-1 text-gray-300">Stay updated on the latest in digital trends and insights.</p>


        <input type="text" placeholder="Enter your email address ....." class="border ml-20 mt-6 bntifc">

        <a href="https://www.example.com">
        <img src="/img/linkedin.png" height="35" width="35" class="imgfc1 mt-[-30px]">
        </a>

        <a href="https://www.example.com">
        <img src="/img/twitter.png" height="35" width="35" class="imgfc2 mt-[-34px]">
        </a>

        <a href="https://www.example.com">
        <img src="/img/facebook.png" height="35" width="35" class="imgfc3 mt-[-34px]">
        </a>

        <a href="https://www.example.com">
        <img src="/img/instagram-svgrepo.png" height="35" width="35" class="imgfc4 mt-[-34px]">
        </a>

</div>
</body>
</html><?php /**PATH C:\laravel_ntpl\grassroots\resources\views/front-end/footer.blade.php ENDPATH**/ ?>