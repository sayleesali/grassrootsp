<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!-- tailwindcss cdn link -->
     <script src="https://cdn.tailwindcss.com"></script>

     <!-- CSS file -->
    <link rel="stylesheet" href="{{ asset('css/chstyle.css') }}">

    <!-- Include the Swiper CSS -->
  <link rel="stylesheet" href="https://unpkg.com/swiper/swiper-bundle.min.css">

</head>
<body class="flex justify-center mt-2">

   <!-- start topbar part -->
   <nav class="w-[1300px] h-[100px] bg-black">

     <!-- start topbar part -->
    @include('front-end/header')
   <!-- end topbar part -->

   <!-- start city-head First Component -->
<div class="topimg12">
    <img src="/img/framech.png">
    <p class="looking12 ml-20">Looking to transform the world<span class="text-white">____________</span></p>
   
    <p class="text-white ml-20 text-5xl font-bold mt-2">Welcome To The</p>
    <p class="text-white ml-20 text-5xl font-bold mt-1">CITY <span class="samba12">HEAD</span></p>


    <p class="text-white ml-20 text-base mt-6">The role of a City Head in an organization focused on entrepreneurship and </p>
    <p class="text-white ml-20 text-base">business development, such as the "Grassroots Growth Initiative Inc.," is crucial </p> 
     <p class="text-white ml-20 text-base">for both operational effectiveness and strategic growth.</p>


     <div class="text-white mt-12 ml-20">
     <button class="border border-gray-500 disbutton12">Discover Brite  ></button>

     </div>
</div>

<!-- end city-head First Component -->



<!-- start city-head second Component -->

<div class="w-[1300px] h-[540px] cityhcf">

<p class="text-center text-3xl font-bold">HOW IT WORK</p>


<div class="container">
        <div class="">
            <div class="w-1/2 m-8 mt-8 ml-24">
                <div class="bg-white rounded-lg boxch12">
                    <!-- Content for Box 1 -->
                    <img src="/img/rectangle21.png" class="" height="400" width="400">
                    <p class="cityhcff">A City Head acts as a local leader who oversees the</p>
                    <p class="cityhcff1">organization's activities within a specific city.</p>
                    <p class="cityhcff2"> This position is pivotal in managing relationships</p>
                    <p class="cityhcff3"> with local business owners, entrepreneurs, and  </p>
                    <p class="cityhcff4">professionals, and in facilitating the growth of the </p>
                    <p class="cityhcff5"> organization's network and influence within the city.</p>
                </div>
            </div>
            
        </div>
    </div>

</div>

<!-- end city-head second Component -->




<!-- start city-head third Component -->

<div class="w-[1300px] h-[660px] thirteenblock">

<p class="text-center text-3xl font-bold mt-12">Responsibilities OF <span class="thirtch1">CITY HEAD</span></p>

<p class="text-center mt-6 text-sm thirtch2">This position is pivotal in managing relationships with local
     business owners, entrepreneurs, and professionals,</p>
<p class="text-center text-sm thirtch2">and in facilitating the growth of the organization's 
    network and influence within the city.</p>


    <div class="swiper-container mt-10">
  <div class="swiper-wrapper">
    <div class="swiper-slide">
        <img src="/img/container1.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2">Lead Generation</h2>
      <h2 class="text-lg font-semibold mb-3"> and Distribution</h2>
      <p class="text-sm chsc">Generate leads for IT and marketing</p>
      <p class="text-sm chsc">services and distribute these to relevant</p> 
      <p class="text-sm chsc">parties within the organization. <span class="seecff">see more</span></p>
    </div>
    <div class="swiper-slide">
      <img src="/img/container2.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2">Client Relationship 
      <h2 class="text-lg font-semibold mb-3"> Management</h2>
      <p class="text-sm chsc">Develop and maintain strong relationships</p>
      <p class="text-sm chsc">with key stakeholders in the local business</p>
      <p class="text-sm chsc">community. <span class="seecff">see more</span></p>
    </div>
    <div class="swiper-slide">
    <img src="/img/container3.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2">Marketing 
      <h2 class="text-lg font-semibold mb-3">and Promotion</h2>
      <p class="text-sm chsc">Implement marketing strategies tailored </p>
      <p class="text-sm chsc">to the local market to increase the </p>
      <p class="text-sm chsc">organization's visibility and <span class="seecff">see more</span></p>
    </div>
    <div class="swiper-slide">
    <img src="/img/container4.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2 mb-10">Team Leadership</h2>
      <p class="text-sm chsc">Lead and motivate a local team</p>
      <p class="text-sm chsc">dedicated to marketing, sales, and </p>
      <p class="text-sm chsc">client support. <span class="seecff">see more</span></p>
    </div>
    <div class="swiper-slide">
        <img src="/img/container1.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2">Lead Generation</h2>
      <h2 class="text-lg font-semibold mb-3"> and Distribution</h2>
      <p class="text-sm chsc">Generate leads for IT and marketing</p>
      <p class="text-sm chsc">services and distribute these to relevant</p> 
      <p class="text-sm chsc">parties within the organization. <span class="seecff">see more</span></p>
    </div>
    <div class="swiper-slide">
      <img src="/img/container2.png" height="250" width="320">
      <h2 class="text-lg font-semibold mt-2">Client Relationship 
      <h2 class="text-lg font-semibold mb-3"> Management</h2>
      <p class="text-sm chsc">Develop and maintain strong relationships</p>
      <p class="text-sm chsc">with key stakeholders in the local business</p>
      <p class="text-sm chsc">community. <span class="seecff">see more</span></p>
    </div>
    <!-- Add more boxes as needed -->
  </div>
  <!-- Add Navigation Buttons -->
  <div class="swiper-button-prev sliderprev"></div>
  <div class="swiper-button-next slidernext"></div>

</div>


<!-- Include the Swiper JavaScript -->
<script src="https://unpkg.com/swiper/swiper-bundle.min.js"></script>

<script>
  // Initialize the swiper
  var swiper = new Swiper('.swiper-container', {
    slidesPerView: 4,
    spaceBetween: 20,
    navigation: {
      nextEl: '.swiper-button-next',
      prevEl: '.swiper-button-prev',
    },
    autoplay: {
      delay: 3000, // milliseconds
      disableOnInteraction: false,
    },
  });
</script>


</div>

<!-- end city-head third Component -->




<!-- start city-head fourth Component -->

<div class="w-[1300px] h-[650px] fourteen">

     <p class="text-center mt-2 text-3xl font-bold">Strategic OF <span class="chstrateg">City Head</span></p>

     <p class="text-center text-sm pchfc mt-6">The role of the City Head is thus a blend of strategic oversight, operational management, 
        and community engagement, crucial</p>
     <p class="text-center text-sm pchfc">for driving the organization's success in a specific locality.</p>
    

     
     <img src="/img/elemet1.png" height="500" width="500" class="ml-20 mt-20">

     <img src="/img/elemet2.png" height="400" width="420" class="elemimgch1">

     <img src="/img/elemet3.png" height="220" width="220" class="elemimgch2">
    
    
     <ul class="list-disc text-sm fchecul1">
        <li>
        Strategic Leadership Meeting: Shows the City Head presenting a business 
        <br>plan to a team in a modern office setting.
        </li>
     </ul>

     <ul class="list-disc text-sm fchecul2">
        <li>
        Business Development: Captures the City Head networking at a local 
        <br>business event, interacting with entrepreneurs.
        </li>
     </ul>
    
     <ul class="list-disc text-sm fchecul3">
        <li>
        Marketing Campaign Coordination: Illustrates the City Head managing a 
        <br>promotional outdoor event with banners and a crowd.
        </li>
     </ul>

     <ul class="list-disc text-sm fchecul4">
        <li>
        Data Analysis: Shows the City Head analyzing data on a large monitor in an 
        <br>office surrounded by financial charts and graphs.
        </li>
     </ul>

     <ul class="list-disc text-sm fchecul5">
        <li>
        Team Training Session: Depicts the City Head conducting a session in a 
        <br>conference room, leading discussions and team building activities.
        </li>
     </ul>

     <ul class="list-disc text-sm fchecul6">
        <li>
        Client Issue Resolution: The City Head is resolving a client issue over the 
        <br>phone in an office, demonstrating concern and professionalism.
        </li>
     </ul>
    
    </div>

<!-- end city-head fourth Component -->



<!-- start city-head fifth Component -->

<div class="w-[1300px] h-[450px] fifteenblock">

    <p class="text-center text-3xl font-bold mt-8 earncffift">EARNINGS AND INCENTIVES</p>

    <p class="text-center text-sm mt-4 earncffift1">The City Head earns primarily through commissions 
        based on the business generated from the leads converted and the success of local operations.</p>
    <p class="text-center text-sm earncffift1">Additional incentives might include bonuses for exceeding 
        targets, profit sharing from local operations, and perks associated with client deals.</p>


        <img src="/img/rectangle22.png" class="earncfimgf1">

        <img src="/img/rectangle23.png" class="earncfimgf2">

        <img src="/img/rectangle24.png" class="earncfimgf3">

        <img src="/img/moneyincome-rafiki1.png" class="earncfimgf4">

        <img src="/img/moneyincome-amico2.png" class="earncfimgf5">

        <p class="text-center text-3xl font-bold earncffift4">CITY HEAD</p>

</div>
    
<!-- end city-head fifth Component -->



<!-- start city-head sixth Component -->

<div class="w-[1300px] h-[1350px] sixteenblock">

<p class="text-center text-3xl font-bold mt-6">City Head To Accommodate The 
    <span class="accomcf1">Different Tiers</span></p>

    <p class="text-center text-sm mt-5 accomcf2">cities in India—Tier 1, Tier 2, Tier 3, 
        and Tier 4—it's essential to consider the unique business environments, </p>

    <p class="text-center text-sm accomcf3">market dynamics, and local cultures of each tier</p>


    <div class="flex">
  <!-- Image column -->
  <div class="w-1/2 ml-36 mt-16">
    <img src="/img/rectangle26.png" alt="Image" width="300px" height="300px" class="bordered-box">
    <img src="/img/groupchf1.png" alt="Image" width="330px" height="330px" class="imgfcd1">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="mt-20 text-xl font-bold cbcityhs1">
    <li>1. Cities Mumbai, Delhi, Bangalore</li>
  </ol>

     <ul class="list-disc text-sm mt-5 cbcityhs2">
        <li>
        Focus: High competition, advanced technology integration, large-scale networking <br>events.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs3">
        <li>
        Strategies: Leverage advanced digital marketing, focus on high-value partnerships, and 
        <br>integrate with international markets.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs4">
        <li>
        Challenges: High competition, cost management.
        </li>
     </ul>

  </div>
</div>


<div class="flex">

  <!-- Text column -->
  <div class="w-1/2">
  <ol class="mt-14 text-xl font-bold cbcityhs5">
    <li>2. Cities Pune, Jaipur, Lucknow</li>
  </ol>

     <ul class="list-disc text-sm mt-5 cbcityhs6">
        <li>
        Focus: Growing markets, emerging business opportunities.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs7">
        <li>
       <pre>Strategies: Foster local entrepreneurship through incubators, focus on</pre>
        mid-level enterprise engagement, and tap into growing IT and service 
        sectors.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs8">
        <li>
        Challenges: Balancing rapid growth with sustainable business practices.
        </li>
     </ul>
   </div>

   <!-- Image column -->
  <div class="w-1/2 ml-36 mt-8">
    <img src="/img/rectangle27.png" alt="Image" width="300px" height="300px" class="imgrectch1">
    <img src="/img/groupchf2.png" alt="Image" width="330px" height="330px" class="imgfcd2">
  </div>

</div>


<div class="flex">
  <!-- Image column -->
  <div class="w-1/2 ml-36 mt-8">
    <img src="/img/rectangle28.png" alt="Image" width="300px" height="300px">
    <img src="/img/groupchf1.png" alt="Image" width="330px" height="330px" class="imgfcd3">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="mt-14 text-xl font-bold cbcityhs9">
    <li>3. Cities Nashik, Coimbatore, Surat</li>
  </ol>

     <ul class="list-disc text-sm mt-5 cbcityhs10">
        <li>
        Focus: Developing markets, smaller-scale enterprises.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs11">
        <li>
        Strategies: Community-focused initiatives, support for small businesses, emphasis on 
        <br>local market needs.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs12">
        <li>
        Challenges: Limited resources, need for market education.
        </li>
     </ul>

  </div>
</div>


<div class="flex">

  <!-- Text column -->
  <div class="w-1/2">
  <ol class="mt-14 text-xl font-bold cbcityhs13">
    <li>4. Cities  smaller towns and rural areas</li>
  </ol>

     <ul class="list-disc text-sm mt-5 cbcityhs14">
        <li>
        Focus: Early-stage market development, grassroots growth.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs15">
        <li>
        <pre>Strategies: Educational programs on entrepreneurship, basic IT and digital</pre>
          marketing training, local artisan and crafts promotion.
        </li>
     </ul>

     <ul class="list-disc text-sm mt-1 cbcityhs16">
        <li>
        Challenges: Infrastructure development, digital divide.
        </li>
     </ul>
   </div>

   <!-- Image column -->
  <div class="w-1/2 ml-36 mt-8">
    <img src="/img/rectangle29.png" alt="Image" width="300px" height="300px" class="imgrectch2">
    <img src="/img/groupchf2.png" alt="Image" width="330px" height="330px" class="imgfcd4">
  </div>

</div>

</div>

<!-- end city-head sixth Component -->



<!-- start city-head seventh Component -->

<div class="w-[1300px] h-[640px] nineblock">

<div class="container mx-auto">
        <div class="column testimonial-container">
            <div class="w-1/2 p-4 ml-20 mt-6">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn1.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
            <div class="w-1/2 p-4 ml-36">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn2.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
            <div class="w-1/2 p-4 ml-20">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn3.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
        </div>
    </div>

    <p class="ourcn1 text-3xl font-bold">WHAT OUR</p> 
    <p class="ourcn2 text-3xl font-bold">PAST INTERNS</p>
     <p class="ourcn3 text-3xl font-bold">SAY ?</p>

     <button class="border ourcbtnn4 mt-10">See More ></button>
</div>


<!-- end city-head seventh Component -->




<!-- start city-head eighth Component -->

<div class="w-[1300px] h-[580px] tenblock">

<p class="ml-20 mt-14 font-bold blogcte">Blogs  <span class="lineten">________</span></p>

<p class="ml-20 text-2xl font-bold">OUR BLOGS</p>

<p class="discovercte">Discover how we have helped businesses like yours achieving</p> 
<p class="discovercte1">remarkable success, and envision what we can do for your brand.</p>


<div class="container mx-auto">
        <div class="flex">
            <div class="w-1/2 p-4 mt-8 ml-14">
                <div class="longtencc rounded-lg p-4">
                    <!-- Content for Box 1 -->
                    <img src="/img/ellipse7.png" class="imgteenc" height="250" width="250">
                    <h6 class="text-lg text-white font-bold mb-2 ml-4 hashtenc">#  01</h6>
                    <h5 class="text-2xl text-white font-bold mb-2 ml-2 hashtenc1">Events</h5>
                    <p class="text-white ml-2 mt-0 mt-2">It is a long established fact </p>
                    <p class="text-white ml-2">that a reader will be distracted </p>
                    <p class="text-white ml-2"> by the readable content of a page </p>
                    <p class="text-white ml-2"> when looking at its layout.It is a long </p>
                    <p class="text-white ml-2"> established fact that a reader will be distracted by the </p>
                    <p class="text-white ml-2"> readable content of a page when looking at its layout.</p>
                </div>
            </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="w-1/2 p-4 mt-8 mr-14">
                <div class="longtencc1 rounded-lg p-4">
                    <!-- Content for Box 2 -->
                    <img src="/img/ellipse8.png" class="imgteenc1" height="250" width="250">
                    <h6 class="text-lg text-white font-bold mb-2 ml-4 hashtencc2">#  02</h6>
                    <h5 class="text-2xl text-white font-bold mb-2 ml-2 hashtencc3">Ambassador</h5>
                    <p class="text-white ml-2 mt-0 mt-2">It is a long established fact </p>
                    <p class="text-white ml-2">that a reader will be distracted </p>
                    <p class="text-white ml-2"> by the readable content of a page </p>
                    <p class="text-white ml-2"> when looking at its layout.It is a long </p>
                    <p class="text-white ml-2"> established fact that a reader will be distracted by the </p>
                    <p class="text-white ml-2"> readable content of a page when looking at its layout.</p>
                </div>
            </div>
        </div>
    </div>



    <div class="flex justify-center mt-8">
    <nav class="inline-flex">
        <!-- Previous Page Button -->
        <a href="#" class="px-3 py-1 text-lg rounded-l hover:bg-gray-300 font-bold">< &nbsp;</a>
        
        <!-- Page Numbers -->
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">01</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">02</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">03</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">04</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">05</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">06</a>
        
        <!-- Next Page Button -->
        <a href="#" class="px-3 py-1  text-lg rounded-r hover:bg-gray-300 font-bold">&nbsp; ></a>
    </nav>
</div>

</div>

<!-- end city-head eighth Component -->


<!-- start footer part -->
@include('front-end/footer')
   <!-- end footer part -->
   

</nav>
    
<!-- JS file -->
<script src="{{ asset('js/nscript.js') }}"></script>

</body>
</html>
