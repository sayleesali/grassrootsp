
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
     <!-- tailwindcss cdn link -->
     <script src="https://cdn.tailwindcss.com"></script>

      <!-- CSS file -->
    <link rel="stylesheet" href="{{ asset('css/reshstyle.css') }}">

  
    <!-- icon link -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">


</head>

<body class="flex justify-center">

<nav class="w-[1300px] h-[100px] bg-black">

   <!-- start topbar part -->
    @include('front-end/header')
   <!-- end topbar part -->
  

   <!-- start First Component -->
<div class="topimg">
    <img src="/img/Frame.png">
    <p class="looking">Looking to transform the world<span class="text-white">____________</span></p>
   
    <p class="text-white welc text-5xl font-bold mt-2">Welcome To The</p>
    <p class="text-white welc text-5xl font-bold mt-1">CAMPUS <span class="samba">AMBASSADOR</span></p>


    <p class="text-white whec text-base mt-6">when an unknown printer took a galley of type and scrambled it to make a type</p>
    <p class="text-white whec text-base">specimen book. It has survived not only five centuries, but also the leap into</p> 
     <p class="text-white whec text-base">electronic typesetting, remaining essentially unchanged.</p>


     <div class="text-white mt-12 ml-20">
     <button class="border border-gray-500 disbutton">Discover Brite  ></button>

     </div>
</div>


  <div class="secondblock">
<div class="flex">
  <div class="flex-1 twocc text-3xl font-bold">200+</div>
  <div class="flex-1 twoccc text-3xl font-bold">200+</div>
  <div class="flex-1 thrfo text-3xl font-bold">3400</div>
  <div class="flex-1 thethe text-3xl font-bold">330+</div>
</div>

<div class="h-10 relative fblogvl">
  <div class="absolute left-1/2 bg-black w-px h-full transform -translate-x-1/2"></div>
</div>

<div class="h-10 relative sblogvl">
  <div class="absolute left-1/2 bg-black w-px h-full transform -translate-x-1/2"></div>
</div>

<div class="h-10 relative tblogvl">
  <div class="absolute left-1/2 bg-black w-px h-full transform -translate-x-1/2"></div>
</div>


<div class="flex">
  <div class="flex-1 text-sm uni">No of Universities/Colleges in the</div>
  <div class="flex-1 text-sm cou">Total Courses and</div>
  <div class="flex-1 text-sm num">Total number of</div>
  <div class="flex-1 text-sm rank">Rank A+ colleges</div>
</div>

<div class="flex">
  <div class="flex-1 text-sm camp">Campus Ambassador Program</div>
  <div class="flex-1 text-sm semi">Seminars</div>
  <div class="flex-1 text-sm amba">Ambassadors</div>
  <div class="flex-1 text-sm mt-3"></div>
</div>

  </div>
  <!-- end First Component -->



  <!-- start Second Component -->
  <div class="thirdblock">

<div class="w-36 h-40 srect"></div>

<p class="text-sm bene font-bold">The benefits of becoming an ambassador</p>
<hr class="thrl" style="color:#13c5b3!important;">

<p class="becbene text-3xl font-bold">THE BENEFITS OF</p>
<p class="becbene1 text-3xl font-bold">BECOMING <span class="anamba">AN AMBASSADOR</span></p>


<p class="text-sm becbene2">It is a long established fact that a reader will be distracted by the readable content</p>
<p class="text-sm becbene3">of a page when looking at its layout.It is a long established fact that a reader will </p>
<p class="text-sm becbene4">be distracted by the readable content of a page when looking at its layout.</p>


<div class="tcimg">
<img src="/img/rightabout.png" width=600px; height=630px;>
</div>

<ul class="list-disc flist font-bold">

<li>
Hands-on experience in event management
</li>

</ul>

<p class="text-sm flistp">It is a long established fact that a reader will be distracted by the readable content</p>
<p class="text-sm flistp1">of a page when looking at its layout.</p>


<ul class="list-disc slist font-bold">
<li>
  Appreciation letter from ceo
</li>
</ul>

<p class="slistp text-sm">It is a long established fact that a reader will be distracted by the readable content</p>
<p class="slistp1 text-sm">of a page when looking at its layout.</p>



<ul class="list-disc tlist font-bold">
<li>
  Certificate of excellence/letter of recommendation
</li>
</ul>

<p class="text-sm tlistp">It is a long established fact that a reader will be distracted by the readable</p>
<p class="text-sm tlistp1">content of a page when looking at its layout</p>

</div>
<!-- end Second Component -->    




<!-- start third Component -->

<div class="fourthblock">

<p class="text-3xl text-white camptx font-bold">
    WHY IMPORTANT <span class="camp2">CAMPUS AMBASSADOR PROGRAM</span></p>




    <div class="flex">
  <!-- Image column -->
  <div class="w-1/2 wtc1">
    <img src="/img/rectangle1.png" alt="Image" width=425px; height=270px; class="bordered-box">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="text-white text-2xl wtc2">
    <li>1. Workshops And Seminars</li>
  </ol>

<p class="wtc3 text-wp text-sm">Organize workshops on topics like entrepreneurship, sustainability, or economic development.</p>
<p class="wtc4 text-wp text-sm">Ambassadors can lead these events, helping to educate their peers</p>
<p class="wtc5 text-wp text-sm">and faster skills relevant to the company’s goals.</p>
  </div>
</div>



<div class="flex">
<!-- Text column -->
<div class="w-1/2">
  <ol class="text-white text-2xl wtc6">
    <li>2. Network Events</li>
  </ol>

<p class="wtc7 text-wp text-sm">Facilitate networking meetups with alumni, professionals, and industry experts.</p>
<p class="wtc8 text-wp text-sm">These events can help students build connections, gain insights into their potential</p>
<p class="wtc9 text-wp text-sm">career paths, and understand industry trends.</p>
  </div>
  
  <!-- Image column -->
  <div class="w-1/2">
    <img src="/img/rectangle2.png" alt="Image" width=425px; height=270px; class="bordered-box recti2">
  </div>
</div>


<div class="flex">
  <!-- Image column -->
  <div class="w-1/2 wtc10">
    <img src="/img/rectangle3.png" alt="Image" width=425px; height=270px; class="bordered-box">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="wtc11 text-white text-2xl">
    <li>3. Social Media Campaigns</li>
  </ol>

<p class="wtc12 text-wp text-sm">Have ambassadors run social media campaigns to promote the company's initiatives, events, or </p>
<p class="wtc13 text-wp text-sm">achievements. This could include challenges, competitions, or hashtag campaigns that encourage</p>
<p class="wtc14 text-wp text-sm">interaction and visibility online.</p>
  </div>
</div>


<div class="flex">
<!-- Text column -->
<div class="w-1/2">
  <ol class="wtc15 text-white text-2xl">
    <li>4. Mentorship Programs</li>
  </ol>

<p class="wtc16 text-wp mt-4 text-sm">Establish a mentorship program where ambassadors pair up with newer students to</p>
<p class="wtc17 text-wp text-sm">guide them through their academic and professional journey. This can foster a sense</p>
<p class="wtc18 text-wp text-sm">of community and support on campus.</p>
  </div>
  
  <!-- Image column -->
  <div class="w-1/2">
    <img src="/img/rectangle4.png" alt="Image" width=425px; height=270px; class="bordered-box recti4">
  </div>
</div>


<div class="flex">
  <!-- Image column -->
  <div class="w-1/2 wtc19">
    <img src="/img/rectangle5.png" alt="Image" width=425px; height=270px; class="bordered-box">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="wtc20 text-white text-2xl">
    <li>5. Sustainability Drives</li>
  </ol>

<p class="wtc21 text-wp text-sm">Since the company has a focus on sustainability, ambassadors can organize campus-wide</p>
<p class="wtc22 text-wp text-sm">sustainability drives, such as clean-up days, recycling challenges, or educational sessions on</p>
<p class="wtc23 text-wp text-sm">reducing carbon footprints.</p>
  </div>
</div>


<div class="flex">
<!-- Text column -->
<div class="w-1/2">
  <ol class="text-white text-2xl wtc24">
    <li>6. Innovation Challenges</li>
  </ol>

<p class="wtc25 text-wp text-sm">Host innovation or hackathon events where students can come up with solutions to</p>
<p class="wtc26 text-wp text-sm">real-world problems related to the company's industry. This can stimulate creativity</p>
<p class="wtc27 text-wp text-sm">and practical problem-solving among students.</p>
  </div>
  
  <!-- Image column -->
  <div class="w-1/2">
    <img src="/img/rectangle6.png" alt="Image" width=425px; height=270px; class="bordered-box recti6">
  </div>
</div>


<div class="flex">
  <!-- Image column -->
  <div class="w-1/2 wtc28">
    <img src="/img/rectangle7.png" alt="Image" width=425px; height=270px; class="bordered-box">
  </div>
  
  <!-- Text column -->
  <div class="w-1/2">
  <ol class="wtc29 text-white text-2xl">
    <li>7. Guest Speaker Series</li>
  </ol>

<p class="wtc30 text-wp text-sm">Invite leaders from various industries to speak on topics related to global economic growth and</p>
<p class="wtc31 text-wp text-sm">sustainability. This can provide students with inspirational insights and real-world knowledge.</p>
  </div>
</div>

</div>

<!-- end third Component -->



<!-- start fourth Component -->

<div class="w-[1300px] h-[300px]">
  
   <img src="/img/image6.png">


   <div class="rectif1">
    <img src="/img/rectangle8.png" width=290px; height=290px;>
   </div>

   <div class="rectif2">
    <img src="/img/illustration.png" width=400px; height=340px;>
   </div>

   <div class="rectif3">
    <img src="/img/freepikcharacter.png" width=290px; height=340px;>
   </div>

   <p class="text-5xl font-bold aboutc4">ABOUT</p>

   <p class="text-5xl font-bold campc5">THE CAMPUS</p>

   <p class="text-5xl font-bold campcp6">AMBASSADOR <span class="ambac6">PROGRAM</span></p>

   <p class="textc7 textkc1 text-sm">It is a long established fact that a reader will be distracted by the readable content of a page</p> 
    <p class="textc7 textkc2 text-sm">when looking at its layout.It is a long established fact that a reader will be distracted by the</p>
    <p class="textc7 textkc3 text-sm">readable content of a page when looking at its layout.</p>

   <button class="border btnc8">Join Now ></button>
</div>

<!-- end fourth Component -->




<!-- start fifth Component -->

<div class="fifthblock">

<div class="flex">
  <!-- Image column -->
  <div class="w-1/2 maskimgk1">
    <img src="/img/maskgroup.png" alt="Image" width=425px; height=270px; class="bordered-box">
  </div>
  
  
  <!-- Image column -->
  <div class="w-1/2 maskimgk2">
    <img src="/img/rectangle10.png" alt="Image" width=425px; height=270px; class="bordered-box">
    <img src="/img/frame1.png" alt="Image" width=300px; height=300px; class="bordered-box framecf">
</div>
    </div>


    <div class="flex">
  <!-- Text column -->
  <div class="w-1/2 visk">
  <p class="text-3xl font-bold">Vision →</p>

  <p class="viskp text-sm">Commodo tincidunt lobortis id integer ut ornare</p>
    <p class="viskp1 text-sm">feugiat ac.</p>
  </div>
  
  
  <!-- text column -->
  <div class="w-1/2">
  <p class="text-3xl font-bold miscf">Mission →</p>

  <p class="miscf1 text-sm">Orci volutpat netus nisi viverra molestie ipsum</p>
    <p class="miscf2 text-sm">ipsum facilisis.</p>

</div>
    </div>
  
</div>

<!-- end fifth Component -->




<!-- start sixth Component -->

<div class="sixthblock">

<p class="text-2xl font-bold camks">CAMPUS AMBASSADOR PROGRAM FOR</p>

<p class="text-2xl font-bold cstudcs">COLLEGE STUDENTS</p>

<p class="text-sm colstudp">It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.It is a long established</p> 
<p class="text-sm colstudp1">fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>


<div class="flex justify-center">
<button class="border text-white csbtncs">Apply for Campus Ambassador Program</button>
</div>


<div class="grid grid-cols-4 gap-4 gbrect">
  <div class=" p-4">
    <img src="/img/subtract.png" class="rectsimg">
    <img src="/img/rectangle12.png" class="rectsimg3">
    <img src="/img/rectangle11.png" class="rectsimg1">
    <img src="/img/group.png" class="rectsimg2">
  </div>

  <div class="p-4">
  <img src="/img/subtract.png" class="rectsimg4">
  <img src="/img/rectangle12.png" class="rectsimg5">
  <img src="/img/rectangle11.png" class="rectsimg6">
  <img src="/img/learn.png" class="rectsimg7">
  </div>

  <div class="p-4">
  <img src="/img/subtract.png" class="rectsimg8">
  <img src="/img/rectangle12.png" class="rectsimg9">
  <img src="/img/rectangle11.png" class="rectsimg10">
  <img src="/img/experience.png" class="rectsimg11">
  </div>

  <div class="p-4">
  <img src="/img/subtract.png" class="rectsimg12">
  <img src="/img/rectangle12.png" class="rectsimg13">
  <img src="/img/rectangle11.png" class="rectsimg14">
  <img src="/img/earnmoney.png" class="rectsimg15">
  </div>
</div>


<div class="grid grid-cols-4 gap-4">
  <div class="p-4 font-bold itok">Its Online</div>
  <div class="p-4 font-bold itok1">Learn Skills</div>
  <div class="p-4 font-bold itok2">Certification</div>
  <div class="p-4 font-bold itok3">Rewards</div>
</div>


<div class="grid grid-cols-4 gap-4">
  <div class="p-4 textsc">
    <p class="text-xs">Be an Ambassador from your college</p>
    <p class="text-xs">campus by using our Digital Tools</p>
  </div>
  <div class="p-4 textsc2">
    <p class="text-xs">Get hands-on experience in Social Media</p>
    <p class="text-xs textsc3">and Digital & Event Marketing</p>
  </div>
  <div class="p-4 textsc4">
  <p class="text-xs">Earn Valuable Certification and LOR</p>
    <p class="text-xs textsc5">upon successful completion</p>
  </div>
  <div class="p-4 textsc6">
  <p class="text-xs">Further possibility of becoming a paid</p>
    <p class="text-xs textsc7">intern or full time job with us</p>
  </div>
</div>
</div>

<!-- end sixth Component -->



<!-- strart seven Component -->

<div class="w-[1300px] h-[400px] sevenblock">

<p class="text-white text-3xl font-bold text-center pt-16">How it Works ?</p>


<div class="grid grid-cols-3 gap-2 mt-10">
  <div class="border p-4 worksc1 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
    Application Process</div>
  <div class="border p-4 worksc2 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
    Task Execution</div>
  <div class="border p-4 worksc3 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
  Shortlisting & Selection</div>
</div>


<div>
<img src="/img/fi_chevrons-left.png" class="fiimgsc">
</div>


<div>
<img src="/img/fi_chevrons-left1.png" class="fiimgsc1">
</div>


<div class="grid grid-cols-3 gap-2 mt-10">
  <div class="border p-4 worksc4 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
     Task Execution</div>
  <div class="border p-4 worksc5 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
      Evaluation</div>
  <div class="border p-4 worksc6 text-center border-t-4 border-b-4 border-l-4 border-r-4 font-bold">
   Certification & Rewards</div>
</div>


<div>
<img src="/img/fi_chevrons-left2.png" class="fiimgsc2">
</div>

<div>
<img src="/img/fi_chevrons-left3.png" class="fiimgsc3">
</div>


<div>
<img src="/img/fi_chevrons-left4.png" class="fiimgsc4">
</div>

<div class="h-8 border-l border-white worksc7"></div>

<div class="border-t border-white worksc8"></div>

<div class="h-11 border-l border-white worksc9"></div>

</div>

<!-- end seven Component -->



<!-- start eight Component -->

<div class="w-[1300px] h-[690px] eightblock">

<p class="text-center text-xl font-bold mt-14 abouec">About Us</p>

<p class="text-center text-3xl font-bold">What Will You <span class="beecd">Be Doing ?</span></p>

<p class="mt-8 text-sm text-center longec">It is a long established fact that a reader will be distracted by the readable content of a page 
    when looking at its layout.It is a long established</p> 
<p class="text-sm text-center longec">fact that a reader will be distracted by the readable content 
    of a page when looking at its layout.</p>



    <div class="ml-24 mr-24 mt-10">
        <div class="flex">
            <div class="w-1/2 p-4">
                <div class="bg-white rounded-xl p-8 boxec">
                    <!-- Content for Box 1 -->

                    <img src="/img/rectangle15.png" height="30" width="30">
                    <img src="/img/group1.png" class="mt-[-24px] ml-2" height="20" width="20">
                    <h5 class="text-lg font-bold mb-2 ml-14 mt-[-30px]">Be an Influencer</h5>
            <p class="text-xs ml-14 beinfec">Managing businesses' social media profiles to engage with followers,<p>
            <p class="text-xs ml-14 beinfec">build brand loyalty, and drive traffic to their website.</p>
                </div>
            </div>
            <div class="w-1/2 p-4">
                <div class="bg-white rounded-xl p-8 boxec">
                    <!-- Content for Box 2 -->

                    <img src="/img/rectangle16.png" height="30" width="30">
                    <img src="/img/flowsheet.png" class="mt-[-24px] ml-1" height="20" width="20">
                    <h5 class="text-lg font-bold mb-2 ml-14 mt-[-30px]">Be a Creator</h5>
                    <p class="text-xs ml-14 createcb">Developing and executing content marketing plans to create valuable,</p> 
                      <p class="text-xs ml-14 createcb"> relevant content that attracts and retains customers.</p>
                </div>
            </div>
        </div>
    </div>



    <div class="ml-24 mr-24">
        <div class="flex">
            <div class="w-1/2 p-4">
                <div class="bg-white rounded-xl p-8 boxec">
                    <!-- Content for Box 1 -->

                    <img src="/img/rectangle17.png" height="30" width="30">
                    <img src="/img/peoples-svgrepo-com2.png" class="mt-[-24px] ml-1" height="20" width="20">
                    <h5 class="text-lg font-bold mb-2 ml-14 mt-[-30px]">Build Networking Skills</h5>
<p class="text-xs ml-14 beinfec">Optimizing businesses' websites to rank higher in search engine<p>
<p class="text-xs ml-14 beinfec">results pages (SERPs) and increase organic traffic.</p>
                </div>
            </div>
            <div class="w-1/2 p-4">
                <div class="bg-white rounded-xl p-8 boxec">
                    <!-- Content for Box 2 -->

                    <img src="/img/rectangle18.png" height="30" width="30">
                    <img src="/img/ads_click.png" class="mt-[-24px] ml-1" height="20" width="20">
                    <h5 class="text-lg font-bold mb-2 ml-14 mt-[-30px]">Facilitate Events</h5>
<p class="text-xs ml-14 createcb">Creating and managing PPC campaigns to drive targeted traffic to</p> 
<p class="text-xs ml-14 createcb">businesses' websites and generate leads or sales.</p>
                </div>
            </div>
        </div>
    </div>


    <button class="border ecbtnab text-white">Apply for Campus Ambassador Program</button>

    <!-- <div class="w-36 h-40 ecrect mt-[-109px]"></div> -->
</div>

<!-- end eight Component -->




<!-- start nine Component -->

<div class="w-[1300px] h-[640px] nineblock">

<div class="container mx-auto">
        <div class="column testimonial-container">
            <div class="w-1/2 p-4 ml-20 mt-6">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn1.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
            <div class="w-1/2 p-4 ml-36">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn2.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
            <div class="w-1/2 p-4 ml-20">
                <div class="bg-white rounded-lg p-4 testimonial">
                    <!-- Content for Box 1 -->
                    <img src="/img/maskgroupn3.png">
                    <p class="text-sm ml-28 mt-[-76px]">I would like to thank Digixcel for the outstanding service.</p> 
                    <p class="text-sm ml-28">They have helped my business achieve our digital goals</p>
                    <p class="text-sm ml-28"> quickly and efficiently. </p>
                    <div class="flex ml-28 mt-3">
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>&nbsp;&nbsp;
                    <i class="fas fa-star"></i>
                    </div>
                    <img src="/img/groupnc34.png" class="mt-4 ml-28">
                    <h5 class="text-md font-bold ml-40 mt-[-22px]">John Smith</h5>
                </div>
            </div>
        </div>
    </div>

    <p class="ourcn1 text-3xl font-bold">WHAT OUR</p> 
    <p class="ourcn2 text-3xl font-bold">PAST INTERNS</p>
     <p class="ourcn3 text-3xl font-bold">SAY ?</p>

     <button class="border ourcbtnn4 mt-10">See More ></button>
</div>

<!-- end nine Component -->



<!-- start ten Component -->

<div class="w-[1300px] h-[580px] tenblock">

<p class="ml-20 mt-14 font-bold blogcte">Blogs  <span class="lineten">________</span></p>

<p class="ml-20 text-2xl font-bold">OUR BLOGS</p>

<p class="discovercte">Discover how we have helped businesses like yours achieving</p> 
<p class="discovercte1">remarkable success, and envision what we can do for your brand.</p>


<div class="container mx-auto">
        <div class="flex">
            <div class="w-1/2 p-4 mt-8 ml-14">
                <div class="longtencc rounded-lg p-4">
                    <!-- Content for Box 1 -->
                    <img src="/img/ellipse7.png" class="imgteenc" height="250" width="250">
                    <h6 class="text-lg text-white font-bold mb-2 ml-4 hashtenc">#  01</h6>
                    <h5 class="text-2xl text-white font-bold mb-2 ml-2 hashtenc1">Events</h5>
                    <p class="text-white ml-2 mt-0 mt-2">It is a long established fact </p>
                    <p class="text-white ml-2">that a reader will be distracted </p>
                    <p class="text-white ml-2"> by the readable content of a page </p>
                    <p class="text-white ml-2"> when looking at its layout.It is a long </p>
                    <p class="text-white ml-2"> established fact that a reader will be distracted by the </p>
                    <p class="text-white ml-2"> readable content of a page when looking at its layout.</p>
                </div>
            </div>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
            <div class="w-1/2 p-4 mt-8 mr-14">
                <div class="longtencc1 rounded-lg p-4">
                    <!-- Content for Box 2 -->
                    <img src="/img/ellipse8.png" class="imgteenc1" height="250" width="250">
                    <h6 class="text-lg text-white font-bold mb-2 ml-4 hashtencc2">#  02</h6>
                    <h5 class="text-2xl text-white font-bold mb-2 ml-2 hashtencc3">Ambassador</h5>
                    <p class="text-white ml-2 mt-0 mt-2">It is a long established fact </p>
                    <p class="text-white ml-2">that a reader will be distracted </p>
                    <p class="text-white ml-2"> by the readable content of a page </p>
                    <p class="text-white ml-2"> when looking at its layout.It is a long </p>
                    <p class="text-white ml-2"> established fact that a reader will be distracted by the </p>
                    <p class="text-white ml-2"> readable content of a page when looking at its layout.</p>
                </div>
            </div>
        </div>
    </div>



    <div class="flex justify-center mt-8">
    <nav class="inline-flex">
        <!-- Previous Page Button -->
        <a href="#" class="px-3 py-1 text-lg rounded-l hover:bg-gray-300 font-bold">< &nbsp;</a>
        
        <!-- Page Numbers -->
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">01</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">02</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">03</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">04</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">05</a>
        <a href="#" class="px-3 py-1 mt-1 text-sm hover:bg-gray-300 font-bold">06</a>
        
        <!-- Next Page Button -->
        <a href="#" class="px-3 py-1  text-lg rounded-r hover:bg-gray-300 font-bold">&nbsp; ></a>
    </nav>
</div>

</div>

<!-- end ten Component -->





   <!-- start footer part -->
  @include('front-end/footer')
   <!-- end footer part -->
  
</nav>


 <!-- JS file -->
 <script src="{{ asset('js/nscript.js') }}"></script>
    
 </body>
</html>

