<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });

Route::get('front-end/header', function () {
    return view('front-end/header');
});

Route::get('front-end/home', function () {
    return view('front-end/home');
});

Route::get('front-end/cityhead', function () {
    return view('front-end/cityhead');
});

Route::get('front-end/footer', function () {
    return view('front-end/footer');
});

Route::get('front-end/reshome', function () {
    return view('front-end/reshome');
});
